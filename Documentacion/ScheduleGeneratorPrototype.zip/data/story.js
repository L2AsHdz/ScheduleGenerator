var story = {
 "docName": "ScheduleGenerator",
 "docPath": "P_P_P",
 "docVersion": 100000001,
 "ownerName": "",
 "ownerEmail": "",
 "authorName": "V_V_N",
 "authorEmail": "V_V_E",
 "fileType": "png",
 "disableInteractions": false,
 "highlightHotspot": true,
 "highlightAllHotspots": true,
 "hideGallery": false,
 "zoomEnabled": true,
 "cloud": false,
 "title": "ScheduleGenerator",
 "layersExist": true,
 "pages": [
  {
   "id": "1:4",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Inicio",
   "image": "inicio.png",
   "index": 0,
   "width": 1440,
   "height": 1024,
   "x": -720,
   "y": -512,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 0,
      "y": 105,
      "width": 351,
      "height": 66
     },
     "index": 0,
     "page": 1
    },
    {
     "rect": {
      "x": 0,
      "y": 179,
      "width": 351,
      "height": 66
     },
     "index": 1,
     "page": 2
    },
    {
     "rect": {
      "x": 0,
      "y": 253,
      "width": 351,
      "height": 66
     },
     "index": 2,
     "page": 3
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "1:9",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Configuracion",
   "image": "configuracion.png",
   "index": 1,
   "width": 1440,
   "height": 1024,
   "x": 760,
   "y": -513,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 32,
      "y": 7,
      "width": 287,
      "height": 72
     },
     "index": 3,
     "page": 0
    },
    {
     "rect": {
      "x": 0,
      "y": 179,
      "width": 351,
      "height": 66
     },
     "index": 4,
     "page": 2
    },
    {
     "rect": {
      "x": 0,
      "y": 253,
      "width": 351,
      "height": 66
     },
     "index": 5,
     "page": 3
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "4:244",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Horario Generado",
   "image": "horario-generado.png",
   "index": 2,
   "width": 1440,
   "height": 1024,
   "x": 2240,
   "y": -512,
   "isFrame": true,
   "type": "modal",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 32,
      "y": 7,
      "width": 287,
      "height": 72
     },
     "index": 6,
     "page": 0
    },
    {
     "rect": {
      "x": 0,
      "y": 105,
      "width": 351,
      "height": 66
     },
     "index": 7,
     "page": 1
    },
    {
     "rect": {
      "x": 0,
      "y": 253,
      "width": 351,
      "height": 66
     },
     "index": 8,
     "page": 3
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null,
   "showShadow": true
  },
  {
   "id": "4:247",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Historial de horarios",
   "image": "historial-de-horarios.png",
   "index": 3,
   "width": 1440,
   "height": 1024,
   "x": 3720,
   "y": -512,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 32,
      "y": 7,
      "width": 287,
      "height": 72
     },
     "index": 9,
     "page": 0
    },
    {
     "rect": {
      "x": 0,
      "y": 105,
      "width": 351,
      "height": 66
     },
     "index": 10,
     "page": 1
    },
    {
     "rect": {
      "x": 0,
      "y": 179,
      "width": 351,
      "height": 66
     },
     "index": 11,
     "page": 2
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  }
 ],
 "groups": [
  {
   "id": "0:1",
   "name": "Page 1"
  }
 ],
 "startPageIndex": 0,
 "totalImages": 4
}